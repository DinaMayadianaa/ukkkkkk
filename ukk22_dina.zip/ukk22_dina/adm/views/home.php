<div class="row">
  <div class="col-md-12">
    <h1>HOME.</h1>
    <p>halao slemat datang!</p>
    <h3>ini halaman home yang ditulis saat ini!!!</h3>
    <input type="text" class="form-control">
  </div>
</div>